# ContourAnalysis-for-ImageRecognition
https://www.codeproject.com/Articles/196168/Contour-Analysis-for-Image-Recognition-in-C
